create database LMS
use LMS
use master

update Registration set grade='A'where reg_id=15

alter table registration add course_status varchar(20)

update Registration set course_status='current'

update Section set capacity=1 where section_id='CS-A'

update Student set sem_no=0 ,credits=0 ,cgpa=0.0

update Registration set grade='A' where reg_id=4 and grade='x'

select* from Class
select*from Notifications
select * from evaluation_criteria
select * from evaluations
select * from Attendence
select* from student
select*from section
select* from ACOfficer
select*from teacher
select* from Room
select* from course
delete from course
select* from class
delete from room
select*from student
select* from semester
select* from Registration
select * from class
delete from Semester 
delete from section
delete from Registration
insert into class
values
('CS115','CS-B','aamirraheem','CS-1'),
('CS115','CS-C','aamirraheem','CS-2'),
('CS115','CS-D','aamirraheem','CS-2'),
('CS123','CS-B','aamirraheem','CS-3'),
('CS123','CS-C','aamirraheem','CS-2'),
('CS123','CS-D','aamirraheem','CS-4'),
('CS323','CS-A','aamirraheem','CS-2'),
('CS323','CS-C','aamirraheem','CS-5'),
('CS323','CS-D','aamirraheem','CS-2'),
('CS332','CS-A','aamirraheem','CS-2'),
('CS332','CS-C','aamirraheem','CS-1'),
('CS332','CS-D','aamirraheem','CS-2'),
('CS444','CS-A','aamirraheem','CS-2'),
('CS444','CS-B','aamirraheem','CS-1'),
('CS444','CS-D','aamirraheem','CS-2'),
('CS445','CS-A','aamirraheem','CS-2'),
('CS445','CS-B','aamirraheem','CS-2'),
('CS445','CS-D','aamirraheem','CS-2'),
('CS449','CS-A','aamirraheem','CS-3'),
('CS449','CS-B','aamirraheem','CS-2'),
('CS449','CS-C','aamirraheem','CS-2'),
('CS456','CS-A','aamirraheem','CS-5'),
('CS456','CS-B','aamirraheem','CS-1'),
('CS456','CS-C','aamirraheem','CS-2'),
('CS115','CS-A','aamirraheem','CS-1'),
('CS123','CS-A','aamirraheem','CS-2'),
('CS323','CS-B','sarimbaig','CS-3'),
('CS332','CS-B','sarimbaig','CS-4'),
('CS444','CS-C','sarimbaig','CS-5'),
('CS445','CS-C','taimurbakhshi','CS-1'),
('CS449','CS-D','taimurbakhshi','CS-2'),
('CS456','CS-D','taimurbakhshi','CS-3')


insert into Teacher
values
('aamirraheem','Aamir','Raheem','CS','aamirraheem@lhr.nu.edu.pk','aamir123'),
('sarimbaig','Sarim','Baig','CS','sarim.baig@lhr.nu.edu.pk','sarim123'),
('Taimurbakhshi','Taimur','Bakhsi','CS','taimun.bakhsi@lhr.nu.edu.pk','taimur123')
insert into Room
values
('CS-1','CS',1),
('CS-2','CS',1),
('CS-3','CS',2),
('CS-4','CS',2),
('CS-5','CS',3)
insert into section
values
('CS-A','8:30','10:00',30),
('CS-B','8:30','10:00',30),
('CS-C','10:30','12:00',30),
('CS-D','4:00','6:00',30)
insert into course
values
('CS445','PF',3,1,'CS'),
('CS444','PF-LAB',1,1,'CS'),
('CS332','Islamiyat',3,1,'CS'),
('CS323','Into to Computing',1,1,'CS'),
('CS449','Differential Equations',3,1,'CS'),
('CS115','English Composition',3,1,'CS'),
('CS123','Psychology',3,1,'CS'),
('CS456','SDA',3,1,'CS')

insert into AcOfficer
values
('Rana','SanaUllah','rana@lhr.nu.edu.pk','rana123')


insert into student values ('18L-1215','Saif','Ur Rehman','1999-09-15','l181215@lhr.nu.edu.pk','123','Sanda','03224016585','BSCS',0,0,1)










alter table semester add foreign key(student_id) references Student(student_id) on delete no action on update cascade;
alter table registration add foreign key(reg_id) references semester(reg_no) on delete no action on update cascade;
alter table registration add foreign key(class_number) references class(class_number) on delete no action on update cascade;
alter table class add foreign key(course_code) references course(course_code) on delete no action on update cascade;
alter table class add foreign key(section_id) references section(section_id) on delete no action on update cascade;
alter table class add foreign key(teacher_id) references teacher(teacher_id) on delete no action on update cascade;
alter table class add foreign key(room_id) references room(room_id) on delete no action on update cascade;
alter table Attendence add foreign key(class_number) references class(class_number) on delete no action on update cascade;
alter table evaluations add foreign key(class_number) references class(class_number) on delete no action on update cascade;
alter table evaluation_criteria add foreign key(class_number) references class(class_number) on delete no action on update cascade;
alter table Attendence add foreign key(student_id) references Student(student_id) on delete no action on update cascade;
alter table evaluations add foreign key(student_id) references Student(student_id) on delete no action on update cascade;


select *from course
drop procedure add_course
create procedure add_course 
@c_code varchar(10),@c_name varchar(50),
@crs_credits int, @sem_no int, @dept varchar(5)
as
insert into course
values
(@c_code,@c_name,@crs_credits,@sem_no,@dept)

exec add_course 'CS123','probability',3,1,'CS'
exec add_course 'CS456','physics',3,1,'CS'

--Add room
create procedure enter_room
@r_id varchar(10), @b_no varchar(10),
@r_floor int
as 
insert into room values(@r_id,@b_no,@r_floor)
execute enter_room 'Cs-12','Cs',1
select * from room

--Add section
create procedure add_section
@s_id varchar(10), @st varchar(20),
@et varchar(20)
as 
insert into section values(@s_id,@st,@et)
execute add_section 'Cs-5A','11:00','12:00'
select * from section
delete from student


select * from student



--teacher login
create procedure teacher_login
@email varchar(60),@pass varchar(60),
@output int output
as
if exists(select* from teacher where email=@email and pass=@pass)
begin
	set @output=1
end
else 
begin
	set @output=0
end
exec [dbo].assign_cgpa '18L-0968',4.0

/*new*/
