use LMS
use master
create table Student
(
	student_id varchar(50) primary key,
	first_name varchar(50),
	last_name varchar(50),
	DOB date,
	email varchar(60),
	pass varchar(60),
	student_address varchar(500),
	phone varchar(15),
	Degree varchar(50),
	cgpa float default 0.0,
	credits int,
	sem_no int default 0,
)
create table Semester
(
	reg_no int identity(1,1) primary key,
	sem_no int,
	reg_date date default getdate(),
	credits int,
	student_id varchar(50),/*fk bnana hai*/
)
create table Registration
(
	reg_detail_id int identity(1,1) primary key,
	reg_id int,/*fk bnana hai*/
	class_number int,/*fk banana hai*/
	grade varchar(5),
	grade_date date default getdate(),
	course_status varchar(20),
)
create table Class
(
	class_number int identity(1,1) primary key,	
	course_code varchar(10),/*fk*/
	section_id varchar(10),/*fk*/
	teacher_id varchar(15),/*fk*/
	room_id varchar(10),/*fk*/
)
create table Course
(
	course_code varchar(10) primary key,
	course_name varchar(100),
	crs_credits int,
	sem_no int,
	dept varchar(5),
)
create table Section
(
	section_id varchar(10) primary key,
	start_time varchar(20),
	end_time varchar(20),
	capacity int
)
create table Room
(
	room_id varchar(10) primary key,
	building varchar(10),
	room_floor int
)
create table teacher
(
	teacher_id varchar(15) primary key,
	first_name varchar(50),
	last_name varchar(50),
	dep varchar(10),
	email varchar(50),
	pass varchar(50),
)
create table AcOfficer
(
	first_name varchar(50),
	last_name varchar(50),
	email varchar(60) primary key,
	pass varchar(50),
)
create table Notifications
(
	student_id varchar(50),
	section_id varchar(50),
	course_code varchar(50),
	primary key(student_id,section_id,course_code)
)

create table Attendence
(
	class_number int,
	student_id varchar(50),
	attendence_date date,
	attendence_state varchar
	primary key(class_number,student_id,attendence_date)
)
create table evaluations
(
	class_number int,
	student_id varchar(50),
	evaluation_type varchar(15),
	marks_obtained int
	primary key(class_number,student_id,evaluation_type)
)
create table evaluation_criteria
(
	class_number int,
	evaluation_type varchar(15),
	weightage float,
	total_marks int
	primary key(class_number,evaluation_type)
)