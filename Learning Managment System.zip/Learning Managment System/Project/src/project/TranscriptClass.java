/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Erasure
 */
public class TranscriptClass {
    public String course_code;
    public String name;
    public int credits;
    public String grade;
    public double gradepoints;
}
