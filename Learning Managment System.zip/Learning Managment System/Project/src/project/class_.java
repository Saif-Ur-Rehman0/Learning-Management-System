/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.*; 
import java.util.function.Supplier;
/**
 *
 * @author Erasure
 */
public class class_ {
    public int class_number;
    public String course_code;
    public String Section_id;
    public String Teacher_id;
    public String Room_id;
    public Course crs;
    public sections sec;
    java.util.List<Student> sts;
    java.util.List<evaluation_type> eva;
    public class_(){
        
    }
    public class_(int cl_no,String crs_code,String sec_id,String teach_id,String r_id){
        class_number=cl_no;
        course_code=crs_code;
        Section_id=sec_id;
        Teacher_id=teach_id;
        Room_id=r_id;
        crs=new Course(course_code);
        sec=new sections(Section_id);
        sts=new ArrayList<Student>();
        eva=new ArrayList<evaluation_type>();
        String connectionUrl = "jdbc:sqlserver://localhost;databaseName=LMS;integratedSecurity=true;";
            try
            {
                Connection con= DriverManager.getConnection(connectionUrl);
                CallableStatement cstmt=con.prepareCall("{call dbo.show_all_students_of_class(?)}");
                cstmt.setInt(1, class_number);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    
                    Student s=new Student();
                    s.student_id=r.getString("student_id");
                    s.fname=r.getString("first_name");
                    s.lname=r.getString("last_name");
                    sts.add(s);
                }
            }
            catch(Exception e)
            {
                System.out.print(e.toString());
            }
            try
            {
                Connection con= DriverManager.getConnection(connectionUrl);
                CallableStatement cstmt=con.prepareCall("{call dbo.GetEvaluationTypeInfo(?)}");
                cstmt.setInt(1, class_number);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    String eva_type=r.getString("evaluation_type");
                    int total_marks=r.getInt("total_marks");
                    float weightage=r.getFloat("weightage");
                    evaluation_type s=new evaluation_type(class_number,eva_type,weightage,total_marks,sts);
                    eva.add(s);
                }
            }
            catch(Exception e)
            {
                e.toString();
            }
            
    }
    public java.util.List<evaluation_type> GetEvaluation_Types(){
        return eva;
    }
    public evaluation_type getevaluation(String Evalu){
        evaluation_type a=new evaluation_type();
        for(evaluation_type e:eva){
            if(e.evaluation_type.equals(Evalu)){
                return e;
            }
        }
        return a;
    }
    public void add_evaluation(String eva_type,int total_marks,float weightage){
        evaluation_type e=new evaluation_type();
        e.add_evaluations(class_number, eva_type, weightage, total_marks,sts);
        eva.add(e);
    }
    public java.util.List<GrandTotal> GetGrandTotals(){
        java.util.List<GrandTotal>gt;
        gt=new ArrayList<GrandTotal>();
        
        for(Student s:sts){
            GrandTotal g=new GrandTotal();
            g.s=s;
            float total=0;
            float obt_total=0;
            for(evaluation_type e:eva){
                for(evaluation et:e.evas){
                    if(et.student_id.equals(s.student_id)){
                        total=total+e.weightage;
                        obt_total=obt_total+et.obtained_weightage;
                    }
                }
            }
            g.obtained_total=obt_total;
            g.total=total;
            gt.add(g);
        }
        return gt;
    }
    public float remainingweightage(){
        float a=0;
        for(evaluation_type e:eva){
            a=a+e.weightage;
        }
        a=100-a;
        return a;
    }
}
