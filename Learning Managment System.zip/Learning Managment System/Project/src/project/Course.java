/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.sql.*;
/**
 *
 * @author Erasure
 */
public class Course {//course class
    public String CourseCode;
    public String name;
    public int credits;
    public int semester;
    public String dept;
    public String section_id;
    public Course(){
        
    }
    public Course(String crs_code){
        CourseCode=crs_code;        
            try
            {
                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.GetCourseInfo(?)}");
                cstmt.setString(1, crs_code);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    name=r.getString("course_name");
                    credits=r.getInt("crs_credits");
                    semester=r.getInt("sem_no");
                    dept=r.getString("dept");
                }
            }
            catch(Exception e)
            {
                e.toString();
            }
    }
}
