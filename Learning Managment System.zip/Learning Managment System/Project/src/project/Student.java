/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Erasure
 */
public class Student 
{
 public String student_id;
 public String fname;
 public String lname;
 public String DOB;
 public String email;
 public String pass;
 public String stu_addr;
 public String phone;
 public String Degree;
 public float cgpa;
 public int credits;
 public int sem_no;
 public int reg_no;
}
