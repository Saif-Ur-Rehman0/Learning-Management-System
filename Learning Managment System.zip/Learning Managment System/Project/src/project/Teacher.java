/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Erasure
 */
public class Teacher {
    public String teacher_id;
    public String fname;
    public String lname;
    public String email;
    public String pass;
    public String dept;
    java.util.List<class_> cls;
    public Teacher(){
        
    }
    public Teacher(String emailt,String passt){
        email=emailt;
        pass=passt;
        cls=new ArrayList<class_>();
        
            try
            {
                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.GetTeacherInfo(?)}");
                cstmt.setString(1, email);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    teacher_id=r.getString("teacher_id");
                    fname=r.getString("first_name");
                    lname=r.getString("last_name");
                    dept=r.getString("dep");
                }
            }
            catch(Exception e)
            {
                e.toString();
            }
            try
            {
                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.GetClassesOfTeacher(?)}");
                cstmt.setString(1, teacher_id);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    int class_number=r.getInt("class_number");
                    String course_code=r.getString("course_code");
                    String section_id=r.getString("section_id");;
                    String teach_id=r.getString("teacher_id");
                    String room_id=r.getString("room_id");
                    class_ c=new class_(class_number,course_code,section_id,teach_id,room_id);
                    cls.add(c);
                }
            }
            catch(Exception e)
            {
                e.toString();
            }
    }
    public java.util.List<Course> GetCoursesOfTeacher(){
        java.util.List<Course> crs=new ArrayList<Course>();
        
        for(class_ c:cls){
            boolean b=false;
            for(Course cr:crs){
                if(cr.CourseCode.equals(c.course_code)){
                    b=true;
                    break;
                }
            }
            if(b==false){
                crs.add(c.crs);
            }
        }
        return crs;
    }
    public java.util.List<sections> GetSectionsOfTeacher(String crs_code){
        java.util.List<sections> secs=new ArrayList<sections>();
        for(class_ c:cls){
            if(crs_code.equals(c.course_code)){
                    secs.add(c.sec);
            }
        }
        return secs;
    }
    public class_ getclass(String crs_code,String sec_id){
        class_ a=new class_();
        for(class_ c:cls){
            if(crs_code.equals(c.course_code)&&sec_id.equals(c.Section_id)){
                return c;
            }
        }
        return a;
    }
}
