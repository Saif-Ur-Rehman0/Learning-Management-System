/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.util.ArrayList;
/**
 *
 * @author Erasure
 */
public class evaluation_type {
    public int class_number;
    public String evaluation_type;
    public float weightage;
    public int total_marks;
    java.util.List<evaluation> evas;
    
    public evaluation_type(){
        
    }
    public evaluation_type(int class_no,String eva_type,float weight,int total_mark,java.util.List<Student> sts){
        class_number=class_no;
        evaluation_type=eva_type;
        weightage=weight;
        total_marks=total_mark;
        evas=new ArrayList<evaluation>();
        for(Student s:sts){
            evaluation e=new evaluation(class_number,evaluation_type,s,weightage,total_marks);
            if(e.obtained_weightage==null){
                e.obtained_weightage=(float)0;
            }
            evas.add(e);
        }
    }
    public void add_evaluations(int class_no,String eva_type,float weight,int total_mark,java.util.List<Student>sts){
        class_number=class_no;
        evaluation_type=eva_type;
        weightage=weight;
        total_marks=total_mark;
        evas=new ArrayList<evaluation>();
        for(Student s:sts){
            evaluation e=new evaluation(class_no,eva_type,s,weight,0,total_mark);
            evas.add(e);
        }
    }
    public void enter_marks(String student_id,int obtained_marks,Student s){
        evaluation e=new evaluation(class_number,evaluation_type,s,weightage,obtained_marks,total_marks);
        boolean b=false;
        for(evaluation ev:evas){
            if(e.evaluation_type.equals(ev.evaluation_type)&&ev.student_id.equals(s.student_id)){
                ev.marks_obtained=obtained_marks;
                ev.obtained_weightage=e.obtained_weightage;
                b=true;
                break;
            }
        }
        if(b==false){
            evas.add(e);
        }
    }
    public java.util.List<Student> getStudents(){
        java.util.List<Student> sts;
        sts=new ArrayList<Student>();
        for(evaluation e:evas){
            sts.add(e.s);
        }
        return sts;
    }
    public java.util.List<evaluation_type> getdummyvalues(java.util.List<Student>sts){
        evaluation_type e=new evaluation_type();
        e.add_evaluations(class_number, evaluation_type, weightage, total_marks,sts);
        java.util.List<evaluation_type> eva=new ArrayList<evaluation_type>();
        for(evaluation s:evas){
            eva.add(e);
            s.class_number=e.class_number;
        }
        return eva;
    }
}
