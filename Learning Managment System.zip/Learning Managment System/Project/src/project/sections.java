/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.sql.*;
/**
 *
 * @author Erasure
 */
public class sections {
    public String Section_id;
    public String start_time;
    public String end_time;
    public int capacity;
    public sections(){
        
    }
    public sections(String sec_id){
        Section_id=sec_id;
            try
            {
                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.GetSectionInfo(?)}");
                cstmt.setString(1, Section_id);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    start_time=r.getString("start_time");
                    end_time=r.getString("end_time");
                    capacity=r.getInt("capacity");
                }
            }
            catch(Exception e)
            {
                e.toString();
            }
    }
}
