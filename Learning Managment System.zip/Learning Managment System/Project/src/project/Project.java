package project;
import java.awt.event.*;
import java.sql.*;
public class Project 
{
    public void read_students()//to read students from db in a static list
    {
        try
        {
            PreparedStatement statement = connection.conn.prepareStatement("select * from student");    
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                Student s=new Student();
                s.student_id=rs.getString("student_id");
                s.fname=rs.getString("first_name");
                s.lname=rs.getString("last_name");
                s.DOB=rs.getString("DOB");
                s.email=rs.getString("email");
                s.pass=rs.getString("pass");
                s.stu_addr=rs.getString("student_address");
                s.phone=rs.getString("phone");
                s.Degree=rs.getString("Degree");
                s.cgpa=rs.getInt("cgpa");
                s.sem_no=rs.getInt("sem_no");
                DB.students.add(s);
            }
        }
        catch(Exception e)
        {
            System.out.print(e.toString());
        }  
    }
        public void read_sections()//to read sections in a static list
    {
        try
        {
            PreparedStatement statement = connection.conn.prepareStatement("select * from Section"); 
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                sections s=new sections();
                s.Section_id=rs.getString("section_id");
                s.start_time=rs.getString("start_time");
                s.end_time=rs.getString("end_time");
                s.capacity=rs.getInt("capacity");
                DB.sections.add(s);
            }
        }
        catch(SQLException e)
        {
            System.out.print(e.toString());
        }
    }
    public void read_teachers()//to read teachers in a static list
    {
        try
        {
            PreparedStatement statement = connection.conn.prepareStatement("select * from teacher");    
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                Teacher t=new Teacher();
                t.teacher_id=rs.getString("teacher_id");
                t.fname=rs.getString("first_name");
                t.lname=rs.getString("last_name");
                t.dept=rs.getString("dep");
                t.email=rs.getString("email");
                t.pass=rs.getString("pass");
                DB.teachers.add(t);
            }
        }
        catch(Exception e)
        {
            System.out.print(e.toString());
        }
    }
    public void read_courses()//to read all courses in a static list
    {
        try
        {
            PreparedStatement statement = connection.conn.prepareStatement("select * from Course"); 
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                Course c=new Course();
                c.CourseCode=rs.getString("course_code");
                c.name=rs.getString("course_name");
                c.credits=rs.getInt("crs_credits");
                c.semester=rs.getInt("sem_no");
                c.dept=rs.getString("dept");
                DB.courses.add(c);
            }
        }
        catch(Exception e)
        {
            System.out.print(e.toString());
        } 
    }
    public static void main(String args[]) //required main program
    {
        connection.create_connection();//connection opened one time
        Project p=new Project();
        p.read_students();//read required data;
        p.read_sections();
        p.read_courses();
        p.read_teachers();
        LMSMain frame=new LMSMain();//call the main frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosed(WindowEvent e) 
            {
                connection.close_connection();//close connection when main frame exits
            }
        });
    }
}
 
