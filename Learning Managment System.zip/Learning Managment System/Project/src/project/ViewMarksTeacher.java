/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.util.*;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author Erasure
 */
public class ViewMarksTeacher extends javax.swing.JFrame {

     JLabel cc[];
     JLabel co[];
     JLabel ct[];
     JLabel cow[];
     JLabel ctw[];
     evaluation_type et; 
     GetEvaluationType jf1;
     java.util.List<evaluation_type> eva;
     java.util.List<Student> sts;
     java.util.List<evaluation> evas;
    /**
     * Creates new form ViewMarksTeacher
     */
    public ViewMarksTeacher() {
        initComponents();
        this.setTitle("View Marks");
    }
        public ViewMarksTeacher(evaluation_type eval,GetEvaluationType jf)
    {
        this.setTitle("View Marks");
        jf1=jf;
        et=eval;
        initComponents();
        eva=new ArrayList<evaluation_type>();
        sts=new ArrayList<Student>();
        evas=new ArrayList<evaluation>();
            
            sts=et.getStudents();
            evas=et.evas;
            eva=et.getdummyvalues(sts);
            if(sts.size()==0){
                this.jLabel2.setText("No Students available for the selected section.");
            }
            int v=60;
            
            JLabel cid=new JLabel("Student ID");
            cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
            cid.setSize(100, 20); 
            cid.setLocation(45, v); 
            v=v+30;
               cc=new JLabel[sts.size()+1];
               int i=0;
               this.add(cid);
               for(Student s:sts)
               {
                   cc[i]=new JLabel(s.student_id);
                   cc[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cc[i].setSize(110, 20); 
                   cc[i].setLocation(45, v); 
                   v=v+25;
                   this.add(cc[i]);
                   i++;
               }
               cc=new JLabel[sts.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Name");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(140, v); 
               v=v+30;
               this.add(cid);
               for(Student s:sts)
               {
                   cc[i]=new JLabel(s.fname+" "+s.lname);
                   cc[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cc[i].setSize(250, 20); 
                   cc[i].setLocation(120, v); 
                   v=v+25;
                   this.add(cc[i]);
                   i++;
               }
               co=new JLabel[evas.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Obtained Marks");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(230, v); 
               v=v+30; 
               this.add(cid);
               for(evaluation s:evas)
               {
                   co[i]=new JLabel(String.valueOf(s.marks_obtained));
                   co[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   co[i].setSize(50, 20);
                   co[i].setLocation(265, v); 
                   v=v+25;
                   this.add(co[i]);
                   i++;
               }
               ct=new JLabel[eva.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Total Marks");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(330, v); 
               v=v+30;
               this.add(cid);
               for(evaluation_type s:eva)
               {
                   ct[i]=new JLabel(String.valueOf(s.total_marks));
                   ct[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   ct[i].setSize(50, 20); 
                   ct[i].setLocation(360, v); 
                   v=v+25;
                   this.add(ct[i]);
                   i++;
               }
               cow=new JLabel[evas.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Obtained Weightage");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(230, 20); 
               cid.setLocation(430, v); 
               v=v+30;
               this.add(cid);
               for(evaluation s:evas)
               {
                   cow[i]=new JLabel(String.valueOf(s.obtained_weightage));
                   cow[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cow[i].setSize(50, 20); 
                   cow[i].setLocation(470, v); 
                   v=v+25;
                   this.add(cow[i]);
                   i++;
               }
               ctw=new JLabel[eva.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Weightage");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(580, v); 
               v=v+30;
               this.add(cid);
               for(evaluation_type s:eva)
               {
                   ctw[i]=new JLabel(String.valueOf(s.weightage));
                   ctw[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   ctw[i].setSize(50, 20);
                   ctw[i].setLocation(600, v); 
                   v=v+25;
                   this.add(ctw[i]);
                   i++;
               }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(695, 334));

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel1.setText("View Marks");

        jButton2.setText("Exit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(186, 186, 186)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 216, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jButton2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 255, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jf1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
