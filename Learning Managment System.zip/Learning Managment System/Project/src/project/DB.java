/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.util.*;
public class DB //class where all static variables persists
{
    static public List<Student> students=new ArrayList<Student>();
    static public List<Course> courses=new ArrayList<Course>();
    static public List<sections> sections=new ArrayList<sections>();
    //static public List<Room> rooms=new ArrayList<Room>();
    static public List<Teacher> teachers=new ArrayList<Teacher>();
    static public List<AOfficer> acofficers=new ArrayList<AOfficer>();
}


