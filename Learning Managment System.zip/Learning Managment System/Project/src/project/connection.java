/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.sql.*;
/**
 *
 * @author Erasure
 */
public class connection 
{
    private static final String connectionUrl = "jdbc:sqlserver://localhost;databaseName=LMS;integratedSecurity=true;";
    static Connection conn=null;
    static public void create_connection()
    {
        try
        {
            conn = DriverManager.getConnection(connectionUrl);
        }
        catch(SQLException es)
        {
            System.out.print(es.toString());
        }
    }
    static public void close_connection()
    {
        try
        {
           if(!conn.isClosed())
            {
                conn.close();
            } 
        }
        catch(SQLException es)
        {
            System.out.print(es.toString());
        }
        
    }
               
}
