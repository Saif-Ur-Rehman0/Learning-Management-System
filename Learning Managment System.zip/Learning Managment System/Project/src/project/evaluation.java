/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author Erasure
 */
public class evaluation {
    public int class_number;
    public String evaluation_type;
    public String student_id;
    public Student s;
    public int marks_obtained;
    public Float obtained_weightage;
    public evaluation(){
        
    }
    public evaluation(int class_no,String eva_type,Student stu,float total_weightage,int total_marks){
        class_number=class_no;
        evaluation_type=eva_type;
        s=stu;
        student_id=s.student_id;
            try
            {
                
                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.GetEvaualtionInfo(?,?,?)}");
                cstmt.setInt(1, class_number);
                cstmt.setString(2, evaluation_type);
                cstmt.setString(3, stu.student_id);
                ResultSet r=cstmt.executeQuery();
                while(r.next())
                {
                    marks_obtained=r.getInt("marks_obtained");
                    obtained_weightage=(float)(marks_obtained*total_weightage);
                    obtained_weightage=(float) obtained_weightage/total_marks;
                }
            }
            catch(Exception e)
            {
                e.toString();
            }
    }
    public evaluation(int class_no,String eva_type,Student stu,float total_weightage,int obtained_marks,int total_marks){
        class_number=class_no;
        evaluation_type=eva_type;
        s=stu;
        student_id=s.student_id;
        marks_obtained=obtained_marks;
        obtained_weightage=(float)(marks_obtained*total_weightage);
        obtained_weightage=(float) obtained_weightage/total_marks;
    }
}
