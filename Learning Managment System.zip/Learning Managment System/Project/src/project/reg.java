/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Erasure
 */
public class reg {
    public static boolean reg=true;
    public static String withdraw="2020-12-27";//new String();
}
