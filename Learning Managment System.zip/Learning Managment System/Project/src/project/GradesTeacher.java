/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.awt.Font;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;


/**
 *
 * @author Erasure
 */
public class GradesTeacher extends javax.swing.JFrame {

    JLabel cc[];
     JTextField co[];
     JLabel ct[];
     JLabel cow[];
     JLabel ctw[];
     class_ c;
     GetSectionTeacher jf1;
     java.util.List<evaluation_type> eva;
     java.util.List<Student> sts;
     java.util.List<evaluation> evas;
     java.util.List<GrandTotal> gt;
    public GradesTeacher() {
        this.setTitle("Assign Grade");
        initComponents();
    }
    public GradesTeacher(class_ cl,GetSectionTeacher jf)
    {
        this.setTitle("Assign Grade");
        jf1=jf;
        c=cl;
        initComponents();
        eva=new ArrayList<evaluation_type>();
        sts=new ArrayList<Student>();
        evas=new ArrayList<evaluation>();
        gt=new ArrayList<GrandTotal>();
        gt=c.GetGrandTotals();
        sts=c.sts;
        if(sts.size()==0){
            this.jLabel2.setText("No Students found.");
        }
            int v=60;
            
            JLabel cid=new JLabel("Student ID");
            cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
            cid.setSize(100, 20); 
            cid.setLocation(45, v); 
            v=v+30;
               cc=new JLabel[sts.size()+1];
               int i=0;
               this.add(cid);
               for(Student s:sts)
               {
                   cc[i]=new JLabel(s.student_id);
                   cc[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cc[i].setSize(110, 20); 
                   cc[i].setLocation(45, v); 
                   v=v+25;
                   this.add(cc[i]);
                   i++;
               }
               cc=new JLabel[sts.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Name");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(140, v); 
               v=v+30;
               this.add(cid);
               for(Student s:sts)
               {
                   cc[i]=new JLabel(s.fname+" "+s.lname);
                   cc[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cc[i].setSize(250, 20); 
                   cc[i].setLocation(120, v); 
                   v=v+25;
                   this.add(cc[i]);
                   i++;
               }
               ct=new JLabel[gt.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Grand Total");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(250, v); 
               v=v+30;
               this.add(cid);
               for(GrandTotal g:gt)
               {
                   ct[i]=new JLabel(String.valueOf(g.obtained_total));
                   ct[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   ct[i].setSize(50, 20); 
                   ct[i].setLocation(265, v); 
                   v=v+25;
                   this.add(ct[i]);
                   i++;
               }
               ct=new JLabel[gt.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Out of");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(360, v); 
               v=v+30;
               this.add(cid);
               for(GrandTotal g:gt)
               {
                   ct[i]=new JLabel(String.valueOf(g.total));
                   ct[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   ct[i].setSize(50, 20); 
                   ct[i].setLocation(360, v); 
                   v=v+25;
                   this.add(ct[i]);
                   i++;
               }
               co=new JTextField[gt.size()+1];
               v=60;
               i=0;
               cid=new JLabel("Grade");
               cid.setFont(new Font("Tahoma", Font.BOLD, 11)); 
               cid.setSize(100, 20); 
               cid.setLocation(450, v); 
               v=v+30; 
               this.add(cid);
               for(GrandTotal g:gt)
               {
                   co[i]=new JTextField();
                   co[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   co[i].setSize(50, 20);
                   co[i].setLocation(445, v); 
                   v=v+25;
                   this.add(co[i]);
                   i++;
               }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel1.setText("Assign Grades");

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(175, 175, 175)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 194, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 296, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jf1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int i=0;
        boolean b=false;
        boolean b2=false;
        if(sts.size()==0){
            this.dispose();
        }
         for(Student c:sts){
             if(co[i].getText().toString().equals("A+")||co[i].getText().toString().equals("A")||co[i].getText().toString().equals("A-")||
                     co[i].getText().toString().equals("B+")||co[i].getText().toString().equals("B")||co[i].getText().toString().equals("B-")||
                     co[i].getText().toString().equals("C+")||co[i].getText().toString().equals("C")||co[i].getText().toString().equals("C-")||
                     co[i].getText().toString().equals("D+")||co[i].getText().toString().equals("D")||co[i].getText().toString().equals("F")){
                 i++;
                 continue;
             }
             else{
                 b=true;
                 if(co[i].getText().toString().length()==0){
                     b2=true;
                 }
             }
             i++;
         }
         if(b==true){
             this.jLabel2.setText("Entered Grades are not valid in some fields.");
         }
         if(b2==true){
             this.jLabel2.setText("Some fields are empty.");
         }
         i=0;
        if(b==false&&b2==false){
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, 1);
            java.util.Date date = cal.getTime();             
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");          
            String inActiveDate = format1.format(date);
            for(Student s:sts){
                String grade=co[i].getText().toString();
                if(grade.equals("A+")||grade.equals("A")||grade.equals("A-")||
                   grade.equals("B+")||grade.equals("B")||grade.equals("B-")||
                   grade.equals("C+")||grade.equals("C")||grade.equals("C-")||
                   grade.equals("D+")||grade.equals("D")||grade.equals("F")){
                    try
                    {
                        CallableStatement cstmt=connection.conn.prepareCall("{call dbo.assign_grade(?,?,?,?)}");
                        cstmt.setInt(1, c.class_number);
                        cstmt.setString(2, s.student_id);
                        cstmt.setString(3, co[i].getText().toString());
                        cstmt.setString(4, inActiveDate);
                        cstmt.execute();
                    }
                    catch(Exception e)
                    {
                        System.out.print(e.toString());
                    }
                    i++;
                }
            }
            this.dispose();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
