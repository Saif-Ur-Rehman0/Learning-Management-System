/*change students semeset no as well*/
package project;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
/**
 *
 * @author Erasure
 */
public class addcourse extends javax.swing.JFrame {

     JLabel cc[];
     JLabel cn[];
     JLabel cr[];
     JComboBox db[];
     JCheckBox cb[];
     Student std;
     java.util.List<Course> lst;
     //java.util.List<sections> DB.sections;
    public addcourse() {
        initComponents();
        this.setTitle("Select Courses");
    }
    public addcourse(Student s)
    {
        this.setTitle("Select Courses");
        std=s;
        initComponents();
        lst=new ArrayList<Course>();
        for(Course c:DB.courses)
        {
            if(c.semester==s.sem_no)
            {
                lst.add(c);
            }
        }
               cc=new JLabel[lst.size()+1];
               int v=60;
               int i=0;
               for(Course c:lst)
               {
                   cc[i]=new JLabel(c.CourseCode);
                   cc[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cc[i].setSize(100, 20); 
                   cc[i].setLocation(45, v); 
                   v=v+25;
                   this.add(cc[i]);
                   i++;
               }
               cn=new JLabel[lst.size()+1];
               v=63;
               i=0;
               for(Course c:lst)
               {
                   cn[i]=new JLabel(c.name);
                   cn[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cn[i].setSize(250, 20); 
                   cn[i].setLocation(128, v); 
                   v=v+25;
                   this.add(cn[i]);
                   i++;
               }
               cr=new JLabel[lst.size()+1];
               v=63;
               i=0;
               for(Course c:lst)
               {
                   cr[i]=new JLabel(Integer.toString(c.credits));
                   cr[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   cr[i].setSize(250, 20); 
                   cr[i].setLocation(455, v); 
                   v=v+25;
                   this.add(cr[i]);
                   i++;
               }
               db=new JComboBox[lst.size()+1];
               v=63;
               i=0;
               for(Course c:lst)
               {
                   db[i]=new JComboBox();
                   db[i].removeAllItems();
                   db[i].setBounds(498, v,70,20);
                   db[i].setFont(new Font("Tahoma", Font.PLAIN, 11)); 
                   for(sections se:DB.sections)
                   {
                       db[i].addItem(se.Section_id);
                   }
                   v=v+25;
                   this.add(db[i]);
                   i++;
               }
               cb=new JCheckBox[lst.size()+1];//checkBox
               i=0;
               v=63;
               for(Course c:lst)
               {
                   cb[i]=new JCheckBox("Register");
                   cb[i].setBounds(570,v, 100,20);
                   int index=i;
                   cb[i].addItemListener(new ItemListener() {

            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED)
                {
                       for(sections s:DB.sections)
                        {
                            if(db[index].getSelectedItem().toString()==s.Section_id)
                            {
                                if(s.capacity<=0)
                                {
                                    JFrame frame=new JFrame();
                                    int a=JOptionPane.showConfirmDialog(frame,"This Section is full, if you want to get notified "
                                            + "when space become available, please select yes\n"
                                            + "Note: you can always choose another section");
                                    if(a==JOptionPane.YES_OPTION)
                                    {
                                        try
                                        {
                                            PreparedStatement statement = connection.conn.prepareStatement("insert into Notifications values(?,?,?)");    
                                            statement.setString(1, std.student_id);
                                            statement.setString(2, s.Section_id);
                                            statement.setString(3, c.CourseCode);
                                            statement.execute();
                                        }
                                        catch(Exception es)
                                        {
                                            System.out.print(es.toString());
                                        }
                                        
                                    }  
                                    break;
                                }   
                            }
                        }
                }
            }
        });
                   v=v+25;
                   this.add(cb[i]);
                   i++;
               }
               
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel1.setText("Please select courses");

        jLabel2.setText("Course Code");

        jLabel3.setText("Course");

        jLabel4.setText("Credits");

        jButton1.setText("Done");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel29.setText("Section");

        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(245, 245, 245)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(282, 282, 282)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel29)))))
                .addContainerGap(133, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2)
                    .addComponent(jLabel29))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 257, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int count=0;
        int j=0;
        for(int i=0;i<lst.size();i++)
        {
            j=0;
            if(cb[i].isSelected())
            {
                for(Course c:lst)
                {
                    if(j==i)
                    {
                        count+=c.credits;
                    }
                    j++;
                }
            }
        }
        if(count==0)
        {
            this.jLabel5.setText("At-least 1 course should be selected with it's lab(if any)");
        }
        else if(count>18)
        {
            this.jLabel5.setText("Please Select Courses worth 18 credits or less");
        }
        else
        {
            int x=0;
            for(sections se:DB.sections)
                {
                    if(db[x].getSelectedItem().toString().equals(se.Section_id) && cb[x].isSelected()==true)
                    {
                        try
                        {
                            se.capacity--;
                            PreparedStatement statement = connection.conn.prepareStatement("update section set capacity=? where section_id=?");
                            statement.setInt(1, se.capacity);
                            statement.setString(2, se.Section_id);
                            statement.execute();
                        }
                        catch(Exception e)
                        {
                           System.out.print(e.toString());
                        }
                        x++;
                    }  
                }
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, 1);
            java.util.Date date = cal.getTime();             
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");          
            String inActiveDate = null;
            try 
            {
                inActiveDate = format1.format(date);
            }
            catch (Exception e1) 
            {
                System.out.print(e1.toString());
            }
            try
            {
                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.get_reg_no(?,?,?,?,?)}");
                cstmt.setInt(1, std.sem_no);
                cstmt.setString(2, inActiveDate);
                cstmt.setInt(3, 18);
                cstmt.setString(4, std.student_id);
                cstmt.registerOutParameter(5, java.sql.Types.INTEGER);
                cstmt.execute();
                std.reg_no=cstmt.getInt("output");
            }
            catch(SQLException e)
            {
                System.out.print(e.toString());
            }
            for(int i=0;i<lst.size();i++)
            {
                j=0;
                if(cb[i].isSelected())
                {
                    for(Course c:lst)
                    {
                        if(j==i)
                        {
                            try
                            {
                                CallableStatement cstmt=connection.conn.prepareCall("{call dbo.student_add_course(?,?,?)}");
                                cstmt.setString(1, db[i].getSelectedItem().toString());
                                cstmt.setString(2, c.CourseCode);
                                cstmt.setInt(3, std.reg_no);
                                cstmt.execute();
                            }
                            catch(Exception e)
                            {
                                e.toString();
                            }
                        }
                        j++;
                    }
                }
            }
            this.dispose();
        } 
    }//GEN-LAST:event_jButton1ActionPerformed
    
    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_formMouseClicked

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_formKeyPressed

    /**
     * @param args the command line arguments
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
