use LMS
--Add student
create procedure add_student
@s_id varchar(50),@f_name varchar(50),@l_name varchar(50),
@dob date,@email varchar(60),@pass varchar(60),@s_addr varchar(500),
@phone varchar(15),@degree varchar(50),@cgpa float,@credits int, @sem_no int
as
insert into student
values
(@s_id,@f_name,@l_name,@dob,@email,@pass,@s_addr,@phone,@degree,@cgpa,@credits,@sem_no)
exec add_student '18L-1014','Muzamil','Hassan','1999-11-11','l181014@lhr.nu.edu.pk','123','Sabzazaaar','03334142073','BSCS',0.0,0,0
exec add_student '18L-0968','M.Ehtesham','Arif','1999-07-11','l180968@lhr.nu.edu.pk','123','qainchi','03334142073','BSCS',0,0,0



--show all courses from a semester number
create procedure show_courses_from_semester
@s_no int
as
select * from Course where Course.sem_no=@s_no
exec show_courses_from_semester 2



--student_login
create procedure student_login
@email varchar(60),@pass varchar(60),
@output int output
as
if exists(select* from student where email=@email and pass=@pass)
begin
	set @output=1
end
else 
begin
	set @output=0
end


create procedure AC_Login
@email varchar(50),@pass varchar(50),@output int output
as
if exists(select*from AcOfficer where email=@email and pass=@pass)
begin
	set @output=1
end
else
begin
	set @output=0
end


create procedure get_reg_no
@sem_no int,@reg_date date,@credits int,@student_id varchar(50),@output int output
as
begin
	insert into Semester
	values
	(@sem_no,@reg_date,@credits,@student_id)
	select @output=reg_no from Semester where sem_no=@sem_no and reg_date=@reg_date and credits =@credits and student_id=@student_id
end

create procedure select_sem_courses
@sem_no int
as
begin
	select * from course where sem_no=@sem_no
end

create procedure check_if_registered
@student_id varchar(50),@sem_no int,@output int output
as
begin
	if exists(select* from Semester where student_id=@student_id and sem_no=@sem_no)
	begin
		set @output=1
	end
	else
	begin
		set @output=0
	end
end

drop procedure student_add_course
create procedure student_add_course
@section_id varchar(50), @course_code varchar(50),@reg_id int
as
begin
declare @c int
select @c=class_number
from class where course_code=@course_code and section_id=@section_id
insert into Registration
values
(@reg_id,@c,'x',null,'current');
end

drop procedure get_registered_courses
create procedure get_registered_courses
@student_id varchar(50)
as
begin
	select course.course_code,Course.course_name,Course.crs_credits,Course.sem_no,Course.dept,class.section_id
	from student as std join Semester as sem on std.student_id=sem.student_id and std.sem_no=sem.sem_no
	join Registration as reg on reg.reg_id=sem.reg_no join Class on reg.class_number=Class.class_number 
	join Course on Course.course_code=class.course_code where std.student_id=@student_id and reg.course_status='current'
end
exec get_registered_courses '18L-1014'

create procedure delete_student_course
@student_id varchar(50),@course_code varchar(50),@section_id varchar(50)
as
begin
	declare @c int
	
	select @c=class_number from class where course_code=@course_code and section_id=@section_id
	print @c
	declare @reg int
	select @reg=reg_no from student join semester on student.student_id=Semester.student_id and student.sem_no=Semester.sem_no where Student.student_id=@student_id
	print @reg
	delete from Registration where reg_id=@reg and class_number=@c
end

create procedure Teacher_Login
@email varchar(50),@pass varchar(50),@output int output
as
if exists(select*from teacher where email=@email and pass=@pass)
begin
	set @output=1
end
else
begin
	set @output=0
end
create procedure mark_attendence
@class_number int,@student_id varchar(50),@attendence_date date,@attendence_state varchar
as
	begin
	if not exists(select * from Attendence where class_number=@class_number and student_id=@student_id and attendence_date=@attendence_date)
	begin
		insert into Attendence 
		values(@class_number,@student_id,@attendence_date,@attendence_state)
	end
	else
	begin
		update Attendence set attendence_state=@attendence_state where class_number=@class_number and student_id=@student_id and attendence_date=@attendence_date
	end
end

create procedure enter_evaluation
@class_number int,@evaluation_type varchar(15),
@weightage float,@total_marks int
as
begin
	if not exists(select * from evaluation_criteria where evaluation_type=@evaluation_type)
	begin
		insert into evaluation_criteria values(@class_number,@evaluation_type,@weightage,@total_marks)
	end
end
create procedure enter_marks_of_a_student
@class_number int,@student_id varchar(50),@evaluation_type varchar(15),@marks_obtained int
as 
begin
	if not exists(select * from evaluations where evaluation_type=@evaluation_type and student_id=@student_id)
	begin
		insert into evaluations values(@class_number,@student_id,@evaluation_type,@marks_obtained)
	end
	else
	begin
		update evaluations set marks_obtained=@marks_obtained where class_number=@class_number and student_id=@student_id and evaluation_type=@evaluation_type;
	end
end
exec enter_marks_of_a_student
create procedure GetTeacherInfo	@email varchar(50)
as
begin
	select *from teacher where email=@email
end
create procedure GetClassesOfTeacher
@teacher_id varchar(15)
as
begin
	select *from Class where teacher_id=@teacher_id
end
create procedure GetCourseInfo
@course_code varchar(10)
as
begin
	select*from Course where course_code=@course_code
end
create procedure GetSectionInfo
@section_id varchar(10)
as
begin
	select* from Section where section_id=@section_id
end
create procedure GetEvaualtionInfo
@class_number int,@evaluation_type varchar(15),@student_id varchar(50)
as
begin
	select *from evaluations where class_number=@class_number and evaluation_type=@evaluation_type and student_id=@student_id
end
create procedure GetEvaluationTypeInfo
@class_number int
as
begin
	select * from evaluation_criteria where class_number=@class_number
end
create procedure assign_grade
@class_number int,@student_id varchar(50),@grade varchar(5),@grade_date date
as
begin
	declare @reg_no int 
	set @reg_no=(select r.reg_detail_id from Semester s join Registration r on s.reg_no=r.reg_id 
	where s.student_id=@student_id and r.class_number=@class_number)
	update Registration set grade=@grade,grade_date=@grade_date 
	where class_number=@class_number and reg_detail_id=@reg_no
end
create procedure show_all_students_of_class
@class_number int
as
begin
	select student_id,first_name,last_name
	from Student
	where student_id in(
		select student_id
		from Semester
		where reg_no in(
			select reg_id
			from Registration
			where class_number=@class_number))
end
exec show_all_students_of_class 66
create procedure show_courses_of_teacher
@teacher_id varchar(15)
as
select distinct c.course_code,course_name,crs_credits,sem_no,dept
from Class c join Course cc on c.course_code=cc.course_code
where @teacher_id=c.teacher_id

create procedure show_sections_of_course_of_teacher
@teacher_id varchar(15),@course_code varchar(10)
as
select s.section_id,s.start_time,s.end_time,s.capacity
from Class c join Section s on c.section_id=s.section_id
where @teacher_id=teacher_id and course_code=@course_code

create procedure view_marks_of_an_evaluation
@class_number int,@evaluation_type varchar(15)
as
begin
select s.student_id,s.first_name,s.last_name,e.marks_obtained,ec.total_marks,ec.weightage,ec.weightage*e.marks_obtained/ec.total_marks as obtained_weightage
from evaluations e join Student s on e.student_id=s.student_id join evaluation_criteria ec on e.evaluation_type=ec.evaluation_type and e.class_number=ec.class_number
where e.class_number=@class_number and e.evaluation_type=@evaluation_type

end

create procedure view_marks_of_a_student
@class_number int,@student_id varchar(50)
as
begin
select e.evaluation_type,e.marks_obtained,ec.total_marks,ec.weightage,ec.weightage*e.marks_obtained/ec.total_marks as obtained_weightage
from evaluations e join Student s on e.student_id=s.student_id join evaluation_criteria ec on e.class_number=ec.class_number
where e.class_number=@class_number and e.student_id=@student_id

end
create procedure check_notifications
@student_id varchar(50)
as
begin
	declare @s varchar(50)
	if exists(select * from Notifications where student_id=@student_id)
	begin
		
		select n.student_id,n.section_id,c.course_code,c.course_name from Notifications as n join Course as c on n.course_code=c.course_code 
		join Section as s on s.section_id=n.section_id where n.student_id=@student_id 
		group by s.capacity,n.student_id,n.section_id,c.course_code,c.course_name having s.capacity>0
	end
end
create procedure assign_cgpa
@student_id varchar(50),@cgpa float 
as
begin
	update Student
	set cgpa=@cgpa where student_id=@student_id
end
create procedure transcript_courses
@student_id varchar(50),@sem int
as
begin
	select cr.course_code,cr.course_name,cr.crs_credits,reg.grade from student as s join Semester as sem on s.student_id=sem.student_id --and sem.sem_no=@sem
	join Registration as reg on sem.reg_no=reg.reg_id join class as c on reg.class_number=c.class_number 
	join Course as cr on cr.course_code=c.course_code where s.student_id=@student_id and sem.sem_no=@sem and reg.course_status='current'
end
create procedure show_all_evaluations
@student_id varchar(50),@course_code varchar(50),@section_id varchar(50)
as
begin
	select ec.evaluation_type,ec.total_marks,e.marks_obtained,ec.weightage from evaluation_criteria as ec join evaluations as e on e.class_number=ec.class_number join class as c on c.class_number=ec.class_number
	where e.student_id=@student_id and c.course_code=@course_code and c.section_id=@section_id
end
create procedure withdraw_student_course
@student_id varchar(50),@course_code varchar(50),@section_id varchar(50)
as
begin
	declare @c_no int
	select @c_no=class_number from class where class.course_code=@course_code and class.section_id=@section_id
	declare @reg int
	select @reg=se.reg_no from Student as s join Semester as se on s.student_id=se.student_id and s.sem_no=se.sem_no where s.student_id=@student_id
	update Registration
	set course_status='withdrawn' where class_number=@c_no and reg_id=@reg
end
create procedure get_student_attendance
@student_id varchar(50),@course_code varchar(50)
as
begin
	select a.attendence_date,a.attendence_state from Attendence as a join Class as c on a.class_number=c.class_number where a.student_id=@student_id and c.course_code=@course_code
end